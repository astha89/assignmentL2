/**
 * 
 */
package com.app.enums;

import com.app.exception.UnknownSymbolException;

/**
 * @author Astha
 *
 */
public enum ValidNumbers {
	I("I"), V("V"), X("X"), L("L"), C("C"), D("D"), M("M");
	
	
	String value;
	ValidNumbers(String value){
		this.value = value;
	}
	
	
	@Override
	public String toString() {
		return this.value;
	}
	
	public static boolean getValidSymbol(Character convertToDecimal) throws UnknownSymbolException{
		
		Boolean valid=true;
		for(ValidNumbers symbol: ValidNumbers.values()){
			if(!symbol.toString().equalsIgnoreCase(convertToDecimal.toString()))
				valid=false;
			throw new UnknownSymbolException("invalid conversion"); 
		}
		return valid;	
	}
}
	

