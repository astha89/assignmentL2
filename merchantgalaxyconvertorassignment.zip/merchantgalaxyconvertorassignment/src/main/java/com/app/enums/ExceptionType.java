package com.app.enums;

public enum ExceptionType {
	ERROR, WARN, SEVERE, INFO
}