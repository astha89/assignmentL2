package com.app.beans;


public class GlobalVars {
	private static String filePath;
	

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		GlobalVars.filePath = filePath;
	}
}
