package com.app.beans;

public class Message {
	
	 public String errorContent="Error : Roman Numeral M cannot repeat 4 times successively";

	public String getErrorContent() {
		return errorContent;
	}

	public void setErrorContent(String errorContent) {
		this.errorContent = errorContent;
	}
}
