package com.app.controller;

import java.io.IOException;
import java.util.Date;
import java.util.logging.Level;

import com.app.beans.GlobalVars;
import com.app.exception.CustomFileNotFoundException;
import com.app.init.ReadConfigMain;
import com.app.services.InputProcessor;
import com.app.services.OutputProcessor;

public class AppController {
	/**
	 * If no argument is provided then the input file present inside resources
	 * package is picked up as input file by default.
	 * 
	 * @param args
	 * @throws CustomFileNotFoundException
	 */
	private static GlobalVars gv;
	private static ReadConfigMain properties;
	private static java.util.logging.Logger globalLogger;
	
	static {
		gv = new GlobalVars();
		properties = new ReadConfigMain();
	
	}
	
	AppController() {
	}
	
	public static void main(String[] args) throws CustomFileNotFoundException, IOException {
		//Initialize application
		init(args);

		try {
			InputProcessor.processFile(gv);
			InputProcessor.mapTokentoIntegerValue();
			OutputProcessor.processReplyForQuestion();
			System.exit(0);
		} catch (Exception e) {
			throw new CustomFileNotFoundException(e.getMessage());
		}
	}
	
	private static void init(String[] args) throws IOException {
		Date time = new Date(System.currentTimeMillis());
		System.out.println("Application initialization started at " + time); 
		if (args.length != 0 && args[0] != null) {
			gv.setFilePath(args[0]);
			System.out.println("Application initialization completed at " + time);
			
		} 
		else {
			if(properties.setPropValues(gv)) {
				//globalLogger.log(Level.INFO, "Application initialization completed at " + time);
			} else {
				System.exit(1);
			}
		}
	}
}
