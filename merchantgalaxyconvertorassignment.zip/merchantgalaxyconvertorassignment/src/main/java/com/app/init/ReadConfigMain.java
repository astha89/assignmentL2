package com.app.init;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.app.beans.GlobalVars;

public class ReadConfigMain {
	boolean result = false;
	InputStream inputStream;
 
	public boolean setPropValues(GlobalVars gv) throws IOException {
 
		try {
			Properties prop = new Properties();
			String propFileName = "config.properties";
 
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
 
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("Config property file '" + propFileName + "' not found in the classpath");
			}
 
			String appFilePath = prop.getProperty("App_filepath");
			
			if(null != appFilePath) {
				gv.setFilePath(appFilePath);
				result = true;
			}
			
			System.out.println("\n Config file loaded properly. \n App path is loaded at path "+ appFilePath);
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
			inputStream.close();
		}
		return result;
	}
}
