/**
 * 
 */
package com.app.exception;

/**
 * @author Astha
 *
 */
public class UnknownSymbolException extends Exception {

	
	private static final long serialVersionUID = 1L;

	public UnknownSymbolException(String message) {
		super(message);
	
	}
}
