package com.app.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import com.app.beans.GlobalVars;
import com.app.enums.ValidNumbers;
import com.app.exception.CustomRomanToDecimalException;
import com.app.exception.RuleViolationException;
import com.app.utilities.ConversionRules;
import com.app.utilities.RomanToDecimal;
/**
 * @author Astha
 *
 */
public class InputProcessor {

	static Map<String, String> tokenRomanValueMapping = new HashMap<String, String>();
	static Map<String, Float> tokenIntegerValue = new HashMap<String, Float>();
	static Map<String, String> questionAndReply = new HashMap<String, String>();
	static ArrayList<String> missingValues = new ArrayList<String>();
	static Map<String, Float> elementValueList = new HashMap<String, Float>();
	private static final String CREDIT = "credits";
	private static final String IS = "is";

	/**
	 * if file path is specified that is picked up else by default Input inside the
	 * same package is pickedup. Each line is picked up and served to processLine()
	 * for processing.
	 * 
	 * @param filePath
	 * @throws IOException
	 */
	public static void processFile(GlobalVars gv) throws IOException {
		BufferedReader bufferedReader = null;
		
		String filePath = gv.getFilePath();
		if (null == filePath) {
			File file = new File(filePath);
			bufferedReader = new BufferedReader(new FileReader(file));
		} else {
			FileReader fileReader = new FileReader(filePath);
			bufferedReader = new BufferedReader(fileReader);
		}
		String line = null;
		while ((line = bufferedReader.readLine()) != null) {
			processLine(line);
		}
		bufferedReader.close();
		
	}

	/**
	 * processline adds the input to various maps<K,T> based on different
	 * conditions.
	 * 
	 * @param line
	 */
	public static void processLine(String line) {
		final int MAX_LENGTH = 3;
		String arr[] = line.split("((?<=:)|(?=:))|( )");

		if (line.endsWith("?")) {
			questionAndReply.put(line, "");
		} else if (arr.length == MAX_LENGTH && arr[1].equalsIgnoreCase(IS)) {
			tokenRomanValueMapping.put(arr[0], arr[arr.length - 1]);
		} else if (line.toLowerCase().endsWith(CREDIT)) {
			missingValues.add(line);
		}
	}

	/**
	 * Maps tokens to Roman equivalent {pish=X, tegj=L, prok=V, glob=I}
	 */
	public static void mapTokentoIntegerValue() {
		tokenRomanValueMapping.forEach((k, v) -> {
			float integerValue = new RomanToDecimal().romanToDecimal(v.toString());
			tokenIntegerValue.put(k.toString(), integerValue);

		});
	
		mapMissingEntities();
	
	}

	/**
	 * FInds the value of elements by decoding queries like [glob glob Silver is 34
	 * Credits]
	 * 
	 * @throws CustomRomanToDecimalException
	 */
	private static void mapMissingEntities() {

		missingValues.forEach(mv -> {
			try {
				deCodeMissingQuery(mv);
			} catch (CustomRomanToDecimalException | RuleViolationException e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * Calculates the values of various elements and appends the same to map
	 * elementValueList. elementValueList :{Gold=14450.0, Iron=195.5, Silver=17.0}
	 * 
	 * @param query
	 * @throws CustomRomanToDecimalException
	 */
	private static void deCodeMissingQuery(String query) throws CustomRomanToDecimalException, RuleViolationException {
		String array[] = query.split("((?<=:)|(?=:))|( )");
		int splitIndex = 0;
		int creditValue = 0;
		String element = null;
		String[] valueofElement = null;
		
			for (int i = 0; i < array.length; i++) {
				if (array[i].toLowerCase().equals(CREDIT)) {
					creditValue = Integer.parseInt(array[i - 1]);
				}
				if (array[i].toLowerCase().equals(IS)) {
					splitIndex = i - 1;
					element = array[i - 1];
				}
				
				valueofElement = java.util.Arrays.copyOfRange(array, 0, splitIndex);
			}

			StringBuilder stringBuilder = new StringBuilder();
			for (int j = 0; j < valueofElement.length; j++) {
				stringBuilder.append(tokenRomanValueMapping.get(valueofElement[j]));
			}
			float valueOfElementInDecimal;

			valueOfElementInDecimal = new RomanToDecimal().romanToDecimal(stringBuilder.toString());

			elementValueList.put(element, creditValue / valueOfElementInDecimal);
			

		
	}

}
