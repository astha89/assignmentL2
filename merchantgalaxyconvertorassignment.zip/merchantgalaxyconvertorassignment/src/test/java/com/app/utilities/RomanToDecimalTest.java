package com.app.utilities;

import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.app.utilities.RomanToDecimal;


public class RomanToDecimalTest{

	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private static final Character[] NonRepeatingRomanNumerals = {'D', 'L', 'V'};
	protected String romanNumeral, anotherRomanNumeral;
	

	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
		System.setErr(new PrintStream(errContent));
	}

	@After
	public void cleanUpStreams() {
		System.setOut(null);
		System.setErr(null);
	}

	@Before
	public void setUp() throws Exception {
		romanNumeral = "MCMXLIV";
		anotherRomanNumeral = "MMMM";
		
	}

	@Test
	/**
	 * Test the scenario of Roman to Numeric Conversion.
	 */
	public void testRomanToDecimal(){
		RomanToDecimal romanToDecimal = new RomanToDecimal();
		float numericValue = romanToDecimal.romanToDecimal(romanNumeral);
		Assert.assertEquals(1944.00, numericValue, 00.00);
	}

	@Test
	/**
	 * Test the scenario where Non repeatable Roman Numeral repeats 4 times successively thereby throwing error.
	 */
	public void testcheckIfLiteralPresent(){
		Character X = 'X';
		boolean result=	ConversionRules.checkIfLiteralPresent(NonRepeatingRomanNumerals, X);
		assertTrue(result);
	 
		}
	@Test
	
	public void testcurrentLiteralSmallerThanPrevious(){
		char X = 'X';
		char V='V';
		
		boolean result=	ConversionRules.CurrentLiteralSmallerThanPrevious(X,V);
		assertTrue(result);
	 
		}
	

}
